function [ acc ] = compute_accuracy( patterns, noise )
%compute_accuracy Calculeaza acuratetea unei retele Hopfield
    acc = rand();
end

%% Tudor Berariu, 2014
