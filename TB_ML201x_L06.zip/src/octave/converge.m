function [ result ] = converge( weights, pattern )
%converge Incearca sa clasifice new_p
    result = pattern;
    % TO DO

end

%% Tudor Berariu, 2014

